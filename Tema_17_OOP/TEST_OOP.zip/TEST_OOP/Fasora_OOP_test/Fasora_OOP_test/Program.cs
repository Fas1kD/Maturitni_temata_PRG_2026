﻿namespace Fasora_OOP_test
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Booking booking1 = new Booking();
            Console.WriteLine("prosim 4 za snahu (musím se hodně pomodlit ať si vytáhnu sítě u maturity :D)");
        }
    }
}
